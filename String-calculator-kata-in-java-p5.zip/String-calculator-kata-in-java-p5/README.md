# String Calculator

Roy Osherove's [String Calculator](http://osherove.com/tdd-kata-1/) code kata, in Java.

See [instructions](instructions.md).

## Compile

Run `gradle build`

## Test

Run `gradle test`

Then, after executing the tests, you can watch the test result on [test report page](./build/reports/tests/test/index.html).
